/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.udea.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Juliana
 */
@Entity
@Table(name = "REGISTRO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Registro.findAll", query = "SELECT r FROM Registro r")
    , @NamedQuery(name = "Registro.findByIdRegistro", query = "SELECT r FROM Registro r WHERE r.idRegistro = :idRegistro")
    , @NamedQuery(name = "Registro.findByNombreEstudiante", query = "SELECT r FROM Registro r WHERE r.nombreEstudiante = :nombreEstudiante")
    , @NamedQuery(name = "Registro.findByIdEstudiante", query = "SELECT r FROM Registro r WHERE r.idEstudiante = :idEstudiante")
    , @NamedQuery(name = "Registro.findByEmail", query = "SELECT r FROM Registro r WHERE r.email = :email")
    , @NamedQuery(name = "Registro.findByFotoEstudiante", query = "SELECT r FROM Registro r WHERE r.fotoEstudiante = :fotoEstudiante")
    , @NamedQuery(name = "Registro.findByNombreMateria", query = "SELECT r FROM Registro r WHERE r.nombreMateria = :nombreMateria")
    , @NamedQuery(name = "Registro.findByCreditos", query = "SELECT r FROM Registro r WHERE r.creditos = :creditos")
    , @NamedQuery(name = "Registro.findByProfesor", query = "SELECT r FROM Registro r WHERE r.profesor = :profesor")
    , @NamedQuery(name = "Registro.findByHorario", query = "SELECT r FROM Registro r WHERE r.horario = :horario")
    , @NamedQuery(name = "Registro.findByIdMatricula", query = "SELECT r FROM Registro r WHERE r.idMatricula = :idMatricula")})
public class Registro implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_REGISTRO", length=50, nullable= false)
    private Integer idRegistro;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "NOMBRE_ESTUDIANTE" , length=50, nullable= false)
    private String nombreEstudiante;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "ID_ESTUDIANTE" , length=50, nullable= false)
    private String idEstudiante;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "EMAIL" , length=50, nullable= false)
    private String email;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "FOTO_ESTUDIANTE" , length=50, nullable= false)
    private String fotoEstudiante;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "NOMBRE_MATERIA" , length=50, nullable= false)
    private String nombreMateria;
    @Basic(optional = false)
    //@NotNull
    //@Column(name = "CREDITOS")
    private int creditos;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PROFESOR" , length=50, nullable= false)
    private String profesor;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "HORARIO", length=50, nullable= false)
    private String horario;
    @Basic(optional = false)
    //@NotNull
    //@Size(min = 1, max = 50)
    @Column(name = "ID_MATRICULA" , length=50, nullable= false)
    private String idMatricula;

    public Registro() {
    }

    public Registro(Integer idRegistro) {
        this.idRegistro = idRegistro;
    }

    public Registro(Integer idRegistro, String nombreEstudiante, String idEstudiante, String email, String fotoEstudiante, String nombreMateria, int creditos, String profesor, String horario, String idMatricula) {
        this.idRegistro = idRegistro;
        this.nombreEstudiante = nombreEstudiante;
        this.idEstudiante = idEstudiante;
        this.email = email;
        this.fotoEstudiante = fotoEstudiante;
        this.nombreMateria = nombreMateria;
        this.creditos = creditos;
        this.profesor = profesor;
        this.horario = horario;
        this.idMatricula = idMatricula;
    }

    public Integer getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(Integer idRegistro) {
        this.idRegistro = idRegistro;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public String getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(String idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFotoEstudiante() {
        return fotoEstudiante;
    }

    public void setFotoEstudiante(String fotoEstudiante) {
        this.fotoEstudiante = fotoEstudiante;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getIdMatricula() {
        return idMatricula;
    }

    public void setIdMatricula(String idMatricula) {
        this.idMatricula = idMatricula;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRegistro != null ? idRegistro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Registro)) {
            return false;
        }
        Registro other = (Registro) object;
        if ((this.idRegistro == null && other.idRegistro != null) || (this.idRegistro != null && !this.idRegistro.equals(other.idRegistro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.udea.modelo.Registro[ idRegistro=" + idRegistro + " ]";
    }

  
}
