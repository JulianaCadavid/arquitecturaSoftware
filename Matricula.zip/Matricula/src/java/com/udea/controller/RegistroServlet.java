/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.udea.controller;

import com.udea.ejb.RegistroFacadeLocal;
import com.udea.modelo.Registro;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Juliana
 */
public class RegistroServlet extends HttpServlet {

    @EJB
    private RegistroFacadeLocal registroFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try{
            String action = request.getParameter("action");
            String url="index.jsp";
            if("list".equals(action)){
                List<Registro> findAll= registroFacade.findAll();
                request.getSession().setAttribute("registros", findAll);
                url="listaRegistro.jsp";
                
                
            } else if ("login".equals(action)){
                String identificacion= request.getParameter("idEstudiante");
                boolean checkLogin = registroFacade.checkLogin(identificacion);
                if(checkLogin){
                    request.getSession().setAttribute("login", identificacion);
                    url="manager.jsp";
                } else {
                    url="login.jsp?error=1";
                }
            } else if("insert".equals(action)){
                Registro a = new Registro();
                a.setNombreEstudiante(request.getParameter("nombreEstudiante"));
                a.setIdEstudiante(request.getParameter("idEstudiante"));
                a.setEmail(request.getParameter("email"));
                a.setNombreMateria(request.getParameter("nombreMateria"));
                a.setProfesor(request.getParameter("profesor"));
                a.setCreditos(0);
                a.setHorario(request.getParameter("horario"));
                a.setIdMatricula(request.getParameter("idMatricula"));
                registroFacade.create(a);
                url="login.jsp";
                
            } else if("delete".equals(action)){
                String id = request.getParameter("idEstudiante");
                Registro a = registroFacade.find(Integer.valueOf(id));
                registroFacade.remove(a);
                url="RegistroServlet?action=list";
                
                
            } else if("logout".equals(action)){
                request.getSession().removeAttribute("login");
                url="login.jsp";
            }
            response.sendRedirect(url);
        } finally{
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
 
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
   

}
